# DRUNKEN-SAILOR-
Desarrollo de Plataformero 2D en pixel art, rápido y preciso, donde el jugador controla a un pirata indefenso. Los niveles deben sentirse amplios, con abundantes enemigos y obstáculos. El objetivo es llegar desde el inicio hasta el final del nivel dentro de un tiempo limitado, atravesando un mapa repleto de amenazas.
